package main

import "Ochoa-Javier-0222/domainUser"

func main() {
	credentialValidatorBuilder := domainUser.GetInstance()
	credentialValidatorNotification := domainUser.NewDomainUserDecorator(credentialValidatorBuilder)

	/*
	Se usa el patron decorator para respetar el contrato de la libreria y solamente agregar la funcionalidad de notificacion de errores.
	La llamada de los diferentes sistemas mantendran la logica actual de exito o error
	para el ejercicio solamente se deja la llamada
	*/
	credentialValidatorNotification.Validate("Javier","0ch0@")
}
