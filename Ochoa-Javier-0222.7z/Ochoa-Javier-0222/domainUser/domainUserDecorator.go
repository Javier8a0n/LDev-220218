package domainUser

import (
	"fmt"
)

type domainUserDecorator struct {
	iCredentialValidator CredentialValidator
}

func NewDomainUserDecorator(iCredentialValidator CredentialValidator) *domainUserDecorator {
	return &domainUserDecorator{iCredentialValidator: iCredentialValidator}
}

func (d *domainUserDecorator) Validate(ID, password string) (user User, invalidUserException error) {
	validateUser, error := d.iCredentialValidator.Validate(ID,password)

	if error != nil {
		/*
		Para el notificador podria hacerse uso de una fachada, donde se estaria agregando los diferentes medios donde se desea notificar.
		LLamar a notificador enviando campos ID, password fecha y hora, para que el notificado se encargue de:
		Llamar implementacion para guardado en DB
		Llamar implementacion para guardar en archivo
		 */
	}
	fmt.Printf("User %s validated successfully", validateUser.Name)

	return validateUser, error
}
