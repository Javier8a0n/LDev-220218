package domainUser

type CredentialValidator interface {
	Validate(ID, password string) (user User, invalidUserException error)
}

type User struct {
	Id    string
	Name  string
	Email string
}

type CredentialValidatorBuilder struct {}

func GetInstance() CredentialValidator {
	return &CredentialValidatorBuilder{}
}

func (c CredentialValidatorBuilder) Validate(ID, password string) (user User, invalidUserException error) {
	return User{
		Id:    "1",
		Name:  "Javier",
		Email: "javier.ochoa@lifemiles.com",
	}, nil
}
