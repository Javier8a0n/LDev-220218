package domainUser

import (
	"reflect"
	"testing"
)

func TestNewDomainUserDecorator(t *testing.T) {
	type args struct {
		iCredentialValidator CredentialValidator
	}
	tests := []struct {
		name string
		args args
		want *domainUserDecorator
	}{
		{
			name: "NewDomainUserDecorator",
			args: args{iCredentialValidator: CredentialValidatorBuilder{}},
			want: NewDomainUserDecorator(CredentialValidatorBuilder{})},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewDomainUserDecorator(tt.args.iCredentialValidator); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewDomainUserDecorator() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_domainUserDecorator_Validate(t *testing.T) {
	type fields struct {
		iCredentialValidator CredentialValidator
	}
	type args struct {
		ID       string
		password string
	}
	tests := []struct {
		name     string
		fields   fields
		args     args
		wantUser User
		wantErr  bool
	}{
		{name: "Success", fields: fields{iCredentialValidator: CredentialValidatorBuilder{}}, args: args{
			ID:       "Javier",
			password: "0ch0@",
		}, wantUser: User{
			Id:    "1",
			Name:  "Javier",
			Email: "javier.ochoa@lifemiles.com",
		}, wantErr: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &domainUserDecorator{
				iCredentialValidator: tt.fields.iCredentialValidator,
			}
			gotUser, err := d.Validate(tt.args.ID, tt.args.password)
			if (err != nil) != tt.wantErr {
				t.Errorf("Validate() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotUser, tt.wantUser) {
				t.Errorf("Validate() gotUser = %v, want %v", gotUser, tt.wantUser)
			}
		})
	}
}
